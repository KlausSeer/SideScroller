#include "Juego.h"

Juego::Juego()
{
	personaje1 = new Personaje(1, 20);
	personaje2 = new Personaje(1, 50);

	elementos = new int;
	*elementos = 0;
}

Juego::~Juego()
{
	delete personaje1, personaje2;
}

void Juego::Mover_Personaje(System::Drawing::Graphics ^g, 
							int intervalo, System::Drawing::Bitmap ^bmp)
{
	g->Clear(System::Drawing::Color::Black);
	personaje1->Caida_libre(g, intervalo,bmp);
	//personaje2->Caida_libre(g, intervalo, bmp);

}
void Juego::Mover_Cuadrados(System::Drawing::Graphics ^g)
{
	for (int i = 0; i < *elementos; i++)
		arreglo[i]->Movimiento(g);
}

bool Juego::Interseccion(Cuadrado* a, Cuadrado* b)
{
	System::Drawing::Rectangle rectangleA ;
	rectangleA.X=a->getX();
	rectangleA.Y= a->getY();
	rectangleA.Width = a->getLado1();
	rectangleA.Height = a->getLado2();
	System::Drawing::Rectangle rectangleB;
	rectangleB.X = b->getX();
	rectangleB.Y = b->getY();
	rectangleB.Width = b->getLado1();
	rectangleB.Height = b->getLado2();

	return rectangleA.IntersectsWith(rectangleB);
	
}
void Juego::Insertar_cuadrado(int px, int py, int plado1, int plado2)
{
	Cuadrado **aux = new Cuadrado*[*elementos + 1];
	for (int i = 0; i < *elementos; i++)
		aux[i] = arreglo[i];
	arreglo = aux;

	arreglo[*elementos] = new Cuadrado(px, py, 30);
	arreglo[*elementos]->setLado1(plado1);
	arreglo[*elementos]->setLado2(plado2);
	*elementos = *elementos + 1;

}
void Juego::Vericar_Colisiones()
{
	for (int i = 0; i < *elementos; i++)
	{
		Cuadrado *a = arreglo[i];
		for (int j = i + 1; j < *elementos; j++)
		{
			Cuadrado *b = arreglo[j];

			if (Interseccion(a, b))
			{
				a->CambiarLadoalamitad();
				a->CambioDir();
				b->CambiarLadoalamitad();
				b->CambioDir();
			}
		}
	}
	 
}
