#pragma once
#include "Personaje.h"
#include "Cuadrado.h"
class Juego
{
	Personaje *personaje1;
	Personaje *personaje2;
	Cuadrado** arreglo;
	int *elementos;

public:
	Juego();
	void Mover_Personaje(System::Drawing::Graphics ^g, 
		                int intervalo,System::Drawing::Bitmap ^bmp);
	void Mover_Cuadrados(System::Drawing::Graphics ^g);
	bool Interseccion(Cuadrado* a, Cuadrado* b);
	void Insertar_cuadrado(int px, int py, int plado1, int plado2);
	
	void Vericar_Colisiones();
	~Juego();
};

