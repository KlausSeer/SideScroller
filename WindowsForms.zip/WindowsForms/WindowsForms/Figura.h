#pragma once
class Figura
{
protected:
	int x, y, dx, dy;
	float t;
public:
	Figura();
	Figura(int px, int py);
	~Figura();
	int getX();
	int getY();
	void  setX(int nuevo);
	void  setY(int nuevo);
};

