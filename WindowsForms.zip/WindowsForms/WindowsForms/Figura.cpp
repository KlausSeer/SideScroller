#include "Figura.h"



Figura::Figura()
{
}


Figura::~Figura()
{
}

Figura::Figura(int px, int py)
{
	System::Random ^r = gcnew System::Random();
	dx = r->Next(5, 10);
    dy= r->Next(5, 10);
	x = px;
	y = py;
	t = 0;
	delete r;
}

int Figura::getX()
{
	return x;
}
int Figura::getY()
{
	return y;
}

void  Figura::setX(int nuevo) {
	x = nuevo;
}
void  Figura::setY(int nuevo) {
	y = nuevo;
}