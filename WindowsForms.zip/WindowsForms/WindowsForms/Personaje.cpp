#include "Personaje.h"



Personaje::Personaje()
{
}


Personaje::~Personaje()
{
}
Personaje::Personaje(int px, int py):Figura(px,py)
{	a = -9.81;
	fila=columna=0;
	y0 = y;
	ymax = y0;
	e = 0;
	nrorebote = 0; 
}
void Personaje::Caida_libre(System::Drawing::Graphics ^g, 
	                        int intervalo,
	                        System::Drawing::Bitmap ^bmp)
{
	int ancho_imagen = bmp->Width / 4;
	int alto_imagen = bmp->Height / 4;
	
	t ++;
	x = x + dx;
	if (y >= g->VisibleClipBounds.Bottom)
	{
		a *= -1;
		nrorebote++;
		ymax = y0 * 2;
		y0 = g->VisibleClipBounds.Bottom -10;
		t = 2;
	}
	if (y < ymax)
	{ 
		y0 = ymax;
		a *= -1;
		t = 2;
	}

	double t2 = t*t;
	double aceleracion = (0.5)*a;
	y = y0 + (dy*t) - (aceleracion*t2);
	System::Drawing::Rectangle cut =
	System::Drawing::Rectangle(columna*ancho_imagen, fila*alto_imagen,
			                       ancho_imagen, alto_imagen);
     //g->DrawImage(bmp,x, y, cut,System::Drawing::GraphicsUnit::Pixel);
	g->FillEllipse(gcnew System::Drawing::SolidBrush(System::Drawing::Color::Red), x, y, 10.0, 10.0);
	 /*columna++; 
	 if (columna > 3) {	 columna = 0;  fila++;	 }
	 if (fila > 3)    { fila = columna = 0; }*/
}