#pragma once
#include <functional>
#include "Juego.h"
class Task
{
	int xinicio, yinicio, xfin, yfin;
	float time = 0.0;
	void(*f)(int, int, int, int);
	bool enabled = true;
public:
	Task();
	Task(void(*pf)(int, int, int, int), int pxinicio, int pyinicio, int pxfin, int pyfin) : f(pf), xinicio(pxinicio), yinicio(pyinicio), xfin(pxfin), yfin(pyfin) {};
	void DoTask(float delayTime);
	bool getEnabled();
	~Task();
};

