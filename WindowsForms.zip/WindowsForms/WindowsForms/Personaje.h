#pragma once
#include "Figura.h"

class Personaje :public Figura
{private:
	float a,e;
	int y0,fila, columna,ymax, nrorebote;
public:
	Personaje();
	Personaje(int px, int py);
	void Caida_libre(System::Drawing::Graphics ^g, int intervalo,
	                 System::Drawing::Bitmap ^bmp );
	~Personaje();
};

