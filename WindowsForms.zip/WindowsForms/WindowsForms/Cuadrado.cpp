#include "Cuadrado.h"



Cuadrado::Cuadrado()
{
}


Cuadrado::~Cuadrado()
{
}
Cuadrado::Cuadrado(int px, int py, int pcolor):Figura(px,py)
{
	System::Random ^r = gcnew System::Random();
	color = pcolor;
	delete r;
}

void Cuadrado::Movimiento(System::Drawing::Graphics ^g)
{
	if (x + dx<g->VisibleClipBounds.Left ||
		x + dx + lado1>g->VisibleClipBounds.Right)
		dx = dx*-1;
	if (y + dy<g->VisibleClipBounds.Top ||
		y + dy + lado2>g->VisibleClipBounds.Bottom)
		dy = dy*-1;

	x += dx;
	y += dy;

	System::Random ^aleatorio = gcnew System::Random();
	int color_r = aleatorio->Next(color, 255);
	int color_g = aleatorio->Next(color*2, 255);
	int color_b = aleatorio->Next(color * 3, 255);
	System::Drawing::Color colorrgb =
		System::Drawing::Color::FromArgb(color_r, color_g, color_b);
	g->FillRectangle(gcnew System::Drawing::SolidBrush(colorrgb),
		x, y, lado1, lado2);
	delete aleatorio;
}

void Cuadrado::CambiarLadoalamitad()
{
	lado1 = lado1 / 2;
	lado2 = lado2 / 2;
}

int Cuadrado::getLado1()
{
	return lado1;
}
void Cuadrado::setLado1(int nuevo)
{
	 lado1=nuevo;
}
int Cuadrado::getLado2()
{
	return lado2;
}
void Cuadrado::CambioDir()
{
	dx *= -1;
	dy *= -1;
}
void Cuadrado::setLado2(int nuevo)
{
	lado2 = nuevo;
}