#pragma once
#include "Figura.h"
class Cuadrado : 	public Figura
{
	int lado1,lado2;
	int color;
public:
	Cuadrado();
	Cuadrado(int px, int py, int pcolor);
	void Movimiento(System::Drawing::Graphics ^g);
	void CambiarLadoalamitad();
	~Cuadrado();
	int getLado1();
	int getLado2();
	void CambioDir();
	void setLado1(int nuevo);
	void setLado2(int nuevo);
};

