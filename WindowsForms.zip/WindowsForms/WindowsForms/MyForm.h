#pragma once
#include "Juego.h"
#include "TaskList.h"
#include <iostream>

Juego *objJuego;

//void Test(int x, int y, int z, int w)
//{
//	std::cout << x << " " << y << " " << z << " " << w << "\n";
//}
//
//void Test2(int x, int y, int z, int w)
//{
//	std::cout << "Este es otro metodo\n";
//}

void Test3(int x, int y, int z, int w)
{
	objJuego->Insertar_cuadrado(x, y, z, w);
}


namespace WindowsForms {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			Tareas = new TaskList();
			objJuego = new Juego();
			xinicio = yinicio = xfin = yfin = -1;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
			delete objJuego;
		}
	private: System::ComponentModel::IContainer^  components;
	protected:
	private: System::Windows::Forms::Timer^  timer1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		
		int xinicio, yinicio, xfin, yfin;
		TaskList* Tareas;
		int lado1 = 0;
		int lado2 = 0;
		float timeDelay = 2.0f;
#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->SuspendLayout();
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Tick += gcnew System::EventHandler(this, &MyForm::timer1_Tick);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 262);
			this->Name = L"MyForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"MyForm";
			this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
			this->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm::MyForm_MouseClick);
			this->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm::MyForm_MouseDown);
			this->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm::MyForm_MouseUp);
			this->ResumeLayout(false);

		}
#pragma endregion

		void A�adir()
		{
			Task* nueva = new Task(Test3, xinicio, yinicio, lado1, lado2);
			Tareas->newTask(nueva);
		}

	private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {
		
		Tareas->doTasks(timeDelay);
		
		Graphics ^g = this->CreateGraphics();
		BufferedGraphicsContext ^bgc =
			BufferedGraphicsManager::Current;
		BufferedGraphics ^bg = bgc->Allocate(g, this->ClientRectangle);
		objJuego->Vericar_Colisiones();
		objJuego->Mover_Cuadrados(bg->Graphics);
		bg->Render(g);
		delete bgc;
		delete bg;
		delete g;
		Tareas->CheckLive();
	}
	private: System::Void MyForm_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		xinicio = e->X;
		yinicio = e->Y;

	}

	private: System::Void MyForm_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {

		if (xinicio != -1 && yinicio != -1) {
			lado1 = System::Math::Abs(xfin - xinicio);
			lado2 = System::Math::Abs(yfin - yinicio);
			A�adir();
			xinicio = yinicio = xfin = yfin = -1;
		}
	}
	private: System::Void MyForm_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		xfin = e->X;
		yfin = e->Y;

	}
	};
}
